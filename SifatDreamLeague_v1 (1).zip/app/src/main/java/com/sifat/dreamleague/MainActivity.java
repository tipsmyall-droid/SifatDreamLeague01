package com.sifat.dreamleague;
import android.app.*;import android.os.*;import android.graphics.*;import android.view.*;import android.content.*;import java.util.*;

public class MainActivity extends Activity{public void onCreate(Bundle b){super.onCreate(b);setContentView(new Game(this));}}
class Game extends View{
 Paint p=new Paint(1); ArrayList<P> blue=new ArrayList<>(),red=new ArrayList<>(); float bx=.5f,by=.49f; int bs=0,rs=0,sel=10; long start;
 Game(Context c){super(c);start=System.currentTimeMillis();setup();postInvalidateDelayed(30);}
 void setup(){float[][] a={{.5f,.89f},{.20f,.78f},{.40f,.80f},{.60f,.80f},{.80f,.78f},{.22f,.62f},{.50f,.66f},{.78f,.62f},{.30f,.45f},{.50f,.40f},{.70f,.45f}};for(int i=0;i<11;i++){blue.add(new P(a[i][0],a[i][1]));red.add(new P(a[i][0],1-a[i][1]));}}
 protected void onDraw(Canvas c){
  int w=getWidth(),h=getHeight();
  p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(12,105,48));c.drawRect(0,0,w,h,p);
  // top HUD
  p.setColor(Color.rgb(20,25,35));c.drawRoundRect(w*.12f,10,w*.88f,68,22,22,p);
  p.setColor(Color.WHITE);p.setTextSize(20);c.drawText("SIFAT DREAM LEAGUE",w*.24f,34,p);
  p.setTextSize(24);c.drawText("BLUE  "+bs+"  -  "+rs+"  RED",w*.27f,60,p);
  // pitch
  p.setColor(Color.WHITE);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);
  c.drawRect(w*.06f,h*.10f,w*.94f,h*.82f,p);c.drawLine(w*.06f,h*.46f,w*.94f,h*.46f,p);c.drawCircle(w*.5f,h*.46f,52,p);
  c.drawRect(w*.30f,h*.10f,w*.70f,h*.21f,p);c.drawRect(w*.30f,h*.71f,w*.70f,h*.82f,p);p.setStyle(Paint.Style.FILL);
  for(int i=0;i<11;i++){drawP(c,blue.get(i),w,h,Color.rgb(35,100,225),i==sel);drawP(c,red.get(i),w,h,Color.rgb(225,45,50),false);}
  p.setColor(Color.WHITE);c.drawCircle(bx*w,by*h,8,p);
  // controls
  p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(Color.WHITE);c.drawCircle(w*.16f,h*.88f,54,p);p.setStyle(Paint.Style.FILL);c.drawCircle(w*.16f,h*.88f,21,p);
  action(c,w,h,.75f,.86f,"PASS");action(c,w,h,.89f,.86f,"SHOOT");action(c,w,h,.89f,.70f,"SWITCH");
  long left=Math.max(0,180-(System.currentTimeMillis()-start)/1000);p.setColor(Color.WHITE);p.setTextSize(18);c.drawText(String.format("%02d:%02d",left/60,left%60),w*.43f,h*.79f,p);
  p.setTextSize(13);c.drawText("OFFLINE  •  11v11",w*.37f,h-10,p);postInvalidateDelayed(30);
 }
 void drawP(Canvas c,P q,int w,int h,int color,boolean s){p.setColor(color);c.drawCircle(q.x*w,q.y*h,14,p);if(s){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.YELLOW);c.drawCircle(q.x*w,q.y*h,20,p);p.setStyle(Paint.Style.FILL);}}
 void action(Canvas c,int w,int h,float x,float y,String s){p.setColor(Color.argb(205,20,20,25));c.drawCircle(x*w,y*h,36,p);p.setColor(Color.WHITE);p.setTextSize(11);c.drawText(s,x*w-18,y*h+4,p);}
 public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN&&e.getAction()!=MotionEvent.ACTION_MOVE)return true;float x=e.getX()/getWidth(),y=e.getY()/getHeight();if(x<.32&&y>.80){P q=blue.get(sel);q.x=Math.max(.08f,Math.min(.92f,q.x+(x-.16f)*.05f));q.y=Math.max(.20f,Math.min(.80f,q.y+(y-.88f)*.05f));}else if(x>.85&&y>.80)shoot();else if(x>.68&&x<.84&&y>.80)pass();else if(x>.84&&y>.62&&y<.77)sel=(sel+1)%11;invalidate();return true;}
 void pass(){P q=blue.get(sel);if(Math.hypot(q.x-bx,q.y-by)<.18){int n=(sel+1)%11;bx=blue.get(n).x;by=blue.get(n).y;sel=n;}}
 void shoot(){P q=blue.get(sel);if(Math.hypot(q.x-bx,q.y-by)<.18){by-=.22;if(by<.11&&bx>.30&&bx<.70){bs++;bx=.5f;by=.46f;}}}
 static class P{float x,y;P(float a,float b){x=a;y=b;}}
}
